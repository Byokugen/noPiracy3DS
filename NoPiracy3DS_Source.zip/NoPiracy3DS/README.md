# NoPiracy3DS

No more piracy!  Lol.

Don't ask.

Credits:
@TricksterGuy       : for using several resources from your template, such as audio.wav, AppInfo, and template.rsf  
@xerpi              : for SF2D and SFIL, both of which were used to create this, as well as for your Makefile  
@WinterMute, @fincs : for the 3DS application template, which was also used to create this  
@B_E_P_I_S_M_A_N    : for the base source code for this application
@xXPaulMCXx         : for the initial idea
@daxtsu             : for the base source code for restarting the system
@Asellus            : for speeding up daxtsu's code